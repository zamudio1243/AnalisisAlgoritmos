package dinamicos;
/*
Hector octubre 2019 
*/

import java.util.ArrayList;

public class Mochila {
    private ArrayList<Item> items;

    public Mochila(ArrayList<Item> items) {
        this.items=items;
    }

    public ArrayList<Item> getItems() {
        return items;
    }

    public void setItems(ArrayList<Item> items) {
        this.items = items;
    }

    @Override
    public String toString(){
        String aux = "";
        for (Item i: this.items) {
            aux += i.toString();
            aux += "\n";
        }
        return aux;
    }


}
